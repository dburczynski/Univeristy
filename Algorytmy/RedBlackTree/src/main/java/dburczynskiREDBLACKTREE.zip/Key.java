public class Key {
    private int key;
    public Key(int key) {
        this.key = key;
    }
    public void setKey(int key) {
        this.key = key;
    }
    public int getKey() {
        return this.key;
    }
}
