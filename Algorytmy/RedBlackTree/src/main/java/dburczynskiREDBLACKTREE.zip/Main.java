public class Main{

    public static void main(String[] args) {
        Node n1 = new Node(4);
        Node n2 = new Node(5);
        Node n3 = new Node(3);
        Node n4 = new Node(10);
        Node n5 = new Node(1);//
        RedBlackTree rbt = new RedBlackTree();

        rbt.insert(n1);
        rbt.insert(n2);
        rbt.insert(n3);
        rbt.insert(n4);
        rbt.insert(n5);

        rbt.printTree(rbt.getRoot());
        System.out.println("\n\nmax depth: "+rbt.findMaxDepth(rbt.getRoot()));
        System.out.println("min depth: "+rbt.findMinDepth(rbt.getRoot()));
        System.out.println("amount of red nodes: "+rbt.countRedNode(rbt.getRoot()));
    }
}