public class Main{

    public static void main(String[] args) {
        Node n1 = new Node(4);
        Node n2 = new Node(2);
        Node n3 = new Node(8);
        Node n4 = new Node(6);
        Node n5 = new Node(12);//
        Node n6 = new Node(10);
        Node n7 = new Node(14);
        Node n8 = new Node(9);
        RedBlackTree rbt = new RedBlackTree();

        rbt.insert(n1);
        rbt.insert(n2);
        rbt.insert(n3);
        rbt.insert(n4);
        rbt.insert(n5);
        rbt.insert(n6);
        rbt.insert(n7);
        rbt.insert(n8);
        rbt.printTree(rbt.getRoot());
        System.out.println("\n\nmax depth: "+rbt.findMaxDepth(rbt.getRoot()));
        System.out.println("min depth: "+rbt.findMinDepth(rbt.getRoot()));
        System.out.println("amount of red nodes: "+rbt.countRedNode(rbt.getRoot()));


        rbt.search(9);
    }
}